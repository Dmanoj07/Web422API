
import React from 'react';
import { useState } from 'react';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import Link from 'next/link';
import Button from 'react-bootstrap/Button'
import Form from 'react-bootstrap/Form'
import { useRouter } from 'next/router';

export default function MainNav() {

    const router = useRouter();
    const [ searchText, setSearchText ] = useState("");

    const handleSubmit = (event) => {
        event.preventDefault();
        router.push(`/artwork?title=true&q=${searchText}`)
    }

    return (
        <>
            <Navbar className="fixed-top navbar-dark bg-dark">
                <Container>
                    <Navbar.Brand className="text-light">Manoj Dhami</Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="me-auto">
                        <Link href="/" passHref legacyBehavior><Nav.Link className="text-light">Movies</Nav.Link></Link>
                        <Link href="/search" passHref legacyBehavior ><Nav.Link className="text-success">Advanced Search</Nav.Link></Link>
                    </Nav>

        {/*  controlled Component */}
                    <Form className="d-flex" onSubmit={handleSubmit}>
                        <Form.Control  type="search" placeholder="Search" className="me-2" aria-label="Search" />
                        <Button type='submit' variant="outline-success" className="btn btn-success text-light" >Search</Button>
                    </Form>

                    </Navbar.Collapse>
                </Container>    
            </Navbar>
            <br /><br />  
        </>
    );
}